package BuissnessLayer;

public class MailCommunication {

}
